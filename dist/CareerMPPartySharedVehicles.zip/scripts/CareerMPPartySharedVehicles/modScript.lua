setExtensionUnloadMode('careerMPPartySharedVehicles', 'manual')
loadManualUnloadExtensions()
